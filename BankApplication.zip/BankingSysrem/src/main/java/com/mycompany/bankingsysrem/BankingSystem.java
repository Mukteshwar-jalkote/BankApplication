/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankingsysrem;

/**
 *
 * @author Mukteshwar jalkote
 */
public class BankingSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
